#include "gtkmm.h"

class en_de_Dlg : public Gtk::Window {
public:
    class ModelColumns : public Gtk::TreeModelColumnRecord {
    public:
        ModelColumns() { add(m_col_id); add(m_col_name); add(m_col_number); add(m_col_percentage); }

        Gtk::TreeModelColumn<unsigned int> m_col_id;
        Gtk::TreeModelColumn<Glib::ustring> m_col_name;
        Gtk::TreeModelColumn<Glib::ustring> m_col_number;
        Gtk::TreeModelColumn<int> m_col_percentage;
        Glib::RefPtr<Gtk::ListStore> m_refTreeModel;
        Gtk::TreeView m_TreeView;
    };
    ModelColumns m_Columns;

    en_de_Dlg(int argc, char* argv[]);
    Pango::FontDescription font, font1, fontnew, m_font, lastpage_font, lastgreen_font;
    Gtk::Layout m_layotimage;
    Gtk::Button bn_encry, bn_descry, bn_file_encrypt, bn_file_decrypt;
    Gtk::Entry encrytentry, resultdisply, secretkentry, secretkDESentry, Descryptentry;
    Gtk::FileChooserButton fileChooserEncrypt, fileChooserDecrypt;

    void on_file_dropped(const Glib::RefPtr<Gdk::DragContext>& context, int x, int y, const Gtk::SelectionData& selection_data, guint info, guint time);
    Gtk::VBox vbox;
    Gtk::Label dragDropLabel;
   // bool on_file_dropped(const Glib::RefPtr<Gdk::DragContext>& context, int x, int y, const Gtk::SelectionData& selection_data, guint info, guint time);

    bool on_bnencry(GdkEventButton* event);
    bool on_bndecry(GdkEventButton* event);
    bool on_bnfileencry();
    bool on_bnfiledecry();

    std::string encryption_Method(const std::string& plaintext_str, const std::string& secret_key);
    std::string decryption_Method(const std::string& encrypted_text, const std::string& secret_key);
    void clearResultText();

    static std::string ResultEncrptionstr;
    static std::string plaintext_str1;
    static std::string text_str1DES;
    static std::string Secrettext_str1;
    static std::string Secrstr1DES;
    static std::string Encrypted_text;
    Gtk::Image topImagehome;
    Glib::RefPtr<Gdk::Pixbuf> framehome;
    Gtk::Entry secret_key_entry;

    std::vector<unsigned char> base64_decode(const std::string& encoded);
    std::string base64_encode(const unsigned char* data, size_t len);
    void handleErrors();

      // Member variables
    std::string draggedFilePath;
   // Gtk::Button bn_select_file;
    Gtk::Button bn_file_encry;
    Gtk::Button bn_file_decry;

          // UI components
  //  Gtk::Label fileLabel;

    // Store the selected file name
    std::string selectedFileName;
  //  bool on_select_file();

    private:
    Gtk::Button bn_select_file,bn_enF,bn_decryF;
    Gtk::Label fileLabel,fileLabel1,fileLabel2;
    Gtk::VBox vbox1,vbox2;
    std::string get_secret_key();
    std::vector<std::string> selected_filenames;  // Store selected filenames

    protected:
    void on_select_file();
    void create_and_encrypt_files(const std::vector<std::string>& filenames, const std::string& secret_key);
    void on_encrypt_files();
    void decrypt_files(const std::vector<std::string>& filenames, const std::string& secret_key);

void on_decrypt_files();
};
